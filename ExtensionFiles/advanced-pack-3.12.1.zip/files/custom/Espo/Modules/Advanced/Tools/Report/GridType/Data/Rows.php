<?php
/***********************************************************************************
 * The contents of this file are subject to the Extension License Agreement
 * ("Agreement") which can be viewed at
 * https://www.espocrm.com/extension-license-agreement/.
 * By copying, installing downloading, or using this file, You have unconditionally
 * agreed to the terms and conditions of the Agreement, and You may not use this
 * file except in compliance with the Agreement. Under the terms of the Agreement,
 * You shall not license, sublicense, sell, resell, rent, lease, lend, distribute,
 * redistribute, market, publish, commercialize, or otherwise transfer rights or
 * usage to the software or any modified version or derivative work of the software
 * created by or for you.
 *
 * Copyright (C) 2015-2026 EspoCRM, Inc.
 *
 * License ID: 010ecf5285437c623f672f7cc474348b
 ************************************************************************************/

namespace Espo\Modules\Advanced\Tools\Report\GridType\Data;

readonly class Rows
{
    /**
     * @param Row[] $rows
     */
    public function __construct(
        public array $rows,
    ) {}

    /**
     * @param array<string, mixed>[] $rows
     */
    public static function fromAssocList(array $rows): self
    {
        return new self(
            rows: array_map(fn ($it) => new Row(row: $it), $rows),
        );
    }

    /**
     * @return array<string, mixed>[]
     */
    public function toAssocList(): array
    {
        return array_map(fn (Row $it) => $it->row, $this->rows);
    }
}

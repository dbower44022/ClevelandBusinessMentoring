<div class="panel panel-default no-side-margin">
    <div class="panel-body panel-body-form">
        <div class="row">
            <div class="cell col-sm-6 form-group">
                <label class="control-label">{{translate 'Entity' scope='Workflow'}}</label>
                <div class="field" data-name="target">{{{target}}}</div>
            </div>
        </div>

        <div class="row">
            <div class="cell col-sm-6 form-group add-field-container">
                {{{addField}}}
            </div>
        </div>

        <div class="row">
            <div class="cell col-md-12">
                <div class="field-definitions form-group"></div>
            </div>
        </div>

        <div class="row">
            <div class="cell col-md-12 form-group hidden" data-name="formula">
                <label class="control-label">{{translate 'Formula' scope='Workflow'}}</label>
                <div class="field" data-name="formula"></div>
            </div>
        </div>
    </div>
</div>
